for (let i = 1; i < 100000; i++) clearInterval(i);
location.reload();
