chrome.storage.local.get(["start"], function (result) {
  console.log(result);
});
